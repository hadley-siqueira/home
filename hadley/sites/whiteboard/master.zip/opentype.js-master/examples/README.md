OpenType.js Examples
====================
Due to security issues, these examples only work when running a local web server.

Run `npm start` in the home directory to start a web server.

Then navigate to one of the examples, e.g.: http://localhost:8080/examples/reading-writing.html

The `generate-font-node.js` example can be run from node.js:

    cd opentype.js/examples
    node generate-font-node.js
    # This generates a font file, called Pyramid-Regular.otf.
