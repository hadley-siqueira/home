OpenType.js is written and maintained by Frederik De Bleser <frederik@debleser.be> & contributors.

Contributors
============================
* Andreas Köberle
* Romuald Bulyshko
* François Pirsch
* Denis Moyogo Jacquerye
* Miguel Sousa
* Louis-Rémi Babé
* Mike Kamermans
* Sascha Brawer
* Joël Galeran
* Gabe Harbs
* Romuald Bulyshko
* Martin Bolot
* Rob Garrison
* Francois Poizat
* Vildan Akchurin
* Josh Marinacci
* Ning Sun
* Adam Lachmanski
* Tom Shinnick
* Andreas Köberle
* Shiro
* Jarda Kotěšovec
* Dima Yv
* Konstantin Käfer
* Victor Powell
* Amit Halberstam
* Jacky Nguyen
* Dominik Lessel
* Ryan Burgett
* 王集鹄
* Axel Kittenberger
* Tom Shinnick
